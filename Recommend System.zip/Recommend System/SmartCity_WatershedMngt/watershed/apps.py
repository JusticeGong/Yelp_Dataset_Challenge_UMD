from django.apps import AppConfig


class WatershedConfig(AppConfig):
    name = 'watershed'
