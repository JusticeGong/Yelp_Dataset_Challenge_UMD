from django.apps import AppConfig


class YelpConfig(AppConfig):
    name = 'yelp'
