from django.apps import AppConfig


class RsConfig(AppConfig):
    name = 'rs'
